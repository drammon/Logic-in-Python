def verifica(i):
    return i >0

num = int(input(""))

if verifica(num):
    print("POSITIVO")
else:
    print("NEGATIVO")